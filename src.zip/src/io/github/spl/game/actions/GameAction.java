package io.github.spl.game.actions; 

/**
 * TODO description
 */
public  interface  GameAction {

}
