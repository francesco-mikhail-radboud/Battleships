package io.github.spl.exceptions; 

/**
 * TODO description
 */
public  class  BattleshipException  extends RuntimeException {
	
	public BattleshipException(String message) {
		super(message);
	}


}
